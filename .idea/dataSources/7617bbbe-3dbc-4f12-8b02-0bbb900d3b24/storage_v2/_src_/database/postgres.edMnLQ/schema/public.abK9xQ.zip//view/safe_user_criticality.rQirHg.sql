create view safe_user_criticality
            (id, user_id, criticality, origin, ohmyform_assessment_id, risk_variables, risk_cases, confirmed_by,
             created_at, updated_at, notes_length, available_ext_specialists)
as
SELECT user_criticality.id,
       user_criticality.user_id,
       user_criticality.criticality,
       user_criticality.origin,
       user_criticality.ohmyform_assessment_id,
       user_criticality.risk_variables,
       user_criticality.risk_cases,
       user_criticality.confirmed_by,
       user_criticality.created_at,
       user_criticality.updated_at,
       length(user_criticality.notes::text) AS notes_length,
       user_criticality.available_ext_specialists
FROM user_criticality;

alter table safe_user_criticality
    owner to postgres;

grant select on safe_user_criticality to metabase_full;

grant select on safe_user_criticality to etlprocess;

