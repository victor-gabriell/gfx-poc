create view safe_patient_intake(id, user_id, created_at, updated_at) as
SELECT patient_intake.id,
       patient_intake.user_id,
       patient_intake.created_at,
       patient_intake.updated_at
FROM patient_intake;

alter table safe_patient_intake
    owner to postgres;

grant select on safe_patient_intake to metabase;

grant select on safe_patient_intake to metabase_full;

grant select on safe_patient_intake to etlprocess;

