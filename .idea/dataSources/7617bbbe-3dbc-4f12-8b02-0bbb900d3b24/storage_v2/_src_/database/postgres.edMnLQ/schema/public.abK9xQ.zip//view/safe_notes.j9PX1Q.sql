create view safe_notes(id, specialist_id, user_id, created_at, updated_at) as
SELECT notes.id,
       notes.specialist_id,
       notes.user_id,
       notes.created_at,
       notes.updated_at
FROM notes;

alter table safe_notes
    owner to postgres;

grant select on safe_notes to metabase;

grant select on safe_notes to metabase_full;

grant select on safe_notes to etlprocess;

